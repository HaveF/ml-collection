function max_no = find_max_no(eta_1)

ind = find( eta_1 == max(eta_1) );
max_no = ind(1);
 