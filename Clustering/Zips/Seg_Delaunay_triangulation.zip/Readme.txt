Invoke the program by calling the GUI function from within Matlab command window:

>> DSeg

Or without GUI

Example,
%   [Segmented, Array]=DS('Image.png'); with the default options
%   [Segmented, Array]=DS('Image.png',0,1,1);



The program and what it does is adequately commented on in the file DS.m
For an exhaustive explanation you can refer to the journal paper:

- A. Cheddad, D. Mohamad and A. Abd Manaf, "Exploiting Voronoi diagram
properties in face segmentation and features extraction," Pattern
Recognition, 41 (12)(2008)3842-3859, Elsevier Science.

Or to the PowerPoint "ITT2008.ppt" which relates to:
A. Cheddad, J. Condell, K. Curran and P. Mc Kevitt. On Points Geometry for Fast Digital Image Segmentation. The 8th International Conference on Information Technology and Telecommunication IT&T 2008, Galway Mayo Institute of Technology, Galway, Ireland 23rd � 24th October 2008, pp: 54-61. 
